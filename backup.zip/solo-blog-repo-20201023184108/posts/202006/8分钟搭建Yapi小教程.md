title: 8分钟搭建Yapi小教程
date: '2020-06-29 23:24:06'
updated: '2020-06-29 23:24:06'
tags: [团队]
permalink: /articles/2020/06/29/1593444245987.html
---
> 废话不多说，直接安装吧~


#### 一、安装nodejs


> 1.获取资源（部署nodejs尽可能选择偶数版本，因为偶数版本官方有较长的维护时间，故这次选择8.x。）

```
curl -sL https://rpm.nodesource.com/setup_8.x | bash -
```

> 2.安装node.js

```
yum install -y nodejs
```

> 3.查看版本检验是否安装成功

```
node -v
```

> 4.查看npm版本

```
npm -v
```

#### 二、安装mongodb


> 1.更新yum源

```
yum -y update
```

> 2.添加mongodb源文件，在/etc/yum.repos.d 创建一个 mongodb-org.repo 文件

```
touch /etc/yum.repos.d/mongodb-org.repo
```

> 3.编辑mongodb-org.repo文件

```
vim /etc/yum.repos.d/mongodb-org.repo
```

> 4.添加文件内容

```
[mongodb-org]
name=MongoDB Repository
baseurl=http://mirrors.aliyun.com/mongodb/yum/redhat/7Server/mongodb-org/3.2/x86_64/
gpgcheck=0
enabled=1
```

> 5.安装mongodb

```
yum install -y mongodb-org
```


> 6.启动mongodb

```
service mongod start
```

> 7.设置开机启动

```
chkconfig mongod on
```

> 8.打开mongoDB客户端程序(可不打开)

```
/bin/mongo
```


> 9.配置远程访问(如本地访问的话，无需配置)

```
修改mongod.conf配置文件
vim/etc/mongod.conf
注释 bindIp: 127.0.0.1
#bindIp: 127.0.0.1
重启mongod
service mongod restart
```



#### 三、安装git

> 官方推荐，在内网部署的时候安装git，可以根据自己所需安装
  
```  
yum -y install git
```

#### 四、安装yapi



> 1.安装Yapi

```
npm install -g yapi-cli --registry https://registry.npm.taobao.org
```

> 2.启动Yapi

```
yapi server
```


#### 五、指定打开端口

```
# 启动防火墙
systemctl start firewalld

# 添加9090端口，初始化yapi时使用
firewall-cmd --zone=public --add-port=9090/tcp --permanent

# 重启防火墙
firewall-cmd --reload

# 检测9090端口是否开放
firewall-cmd --query-port=6379/tcp
```

++如果不是在本地部署的话，需要去云服务器厂商那边开启安全规则对应的端口。++




#### 六、执行 yapi server 启动可视化部署程序

```
在浏览器打开0.0.0.0:9090访问可视化部署地址，如果不是在本地的话访问对应ip:9090
设置相关信息后，会对你填入的邮箱自动生成ymfe.org密码作为管理员登录密码。
```

```
部署成功，请切换到部署目录，输入： "node vendors/server/app.js"
指令启动服务器, 然后在浏览器打开 http://127.0.0.1:3000 访问即可
如果是云服务器换成对应ip即可。
```

