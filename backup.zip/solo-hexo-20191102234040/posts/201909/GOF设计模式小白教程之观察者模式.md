title: GOF设计模式小白教程之观察者模式
date: '2019-09-02 00:06:16'
updated: '2019-09-02 00:06:16'
tags: [设计模式]
permalink: /articles/2019/09/02/1567353976664.html
---

### 观察者模式（Observer）



#### 定义：
指多个对象间存在一对多的依赖关系，当一个对象的状态发生改变时，所有依赖于它的对象都得到通知并被自动更新。这种模式有时又称作发布-订阅模式、模型-视图模式，它是对象行为型模式。



#### 通俗解释：
好比一个网络聊天室模型。有多个聊天者在聊天室内聊天，其中一个聊天者发送一条消息，则需要通知所有聊天者查看消息。例如我们App当中的通知机制也是如此，保存用户的标志，然后挨个给每个用户推送信息。




#### 代码：

抽象主题：提供了一个用于保存观察者对象的聚集类和增加、删除观察者对象的方法，以及通知所有观察者的抽象方法。

```
public abstract class Subject {

    protected List<Observer> observers = new ArrayList();

    public void addObserver(Observer observer) {
        observers.add(observer);
    }

    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    public abstract void notifyObserver();
    
}

```
具体主题：聊天室类，可以通知所有注册过的观察者对象查看新信息。

```
public class Chatroom extends Subject {
    @Override
    public void notifyObserver() {
        // 挨个通知每个观察者
        for (Observer observer : observers) {
            observer.response();
        }
    }

}

```

抽象观察者：拥有一个被通知的方法。


```
public interface Observer {

    public void response();

}
```

具体观察者：聊天者类，有一个提示查看新消息的方法供主题调用。

```
public class Chatter implements Observer {

    private String name;

    public Chatter(String name) {
        this.name = name;
    }

    public void sendMessage(String message) {
        System.out.println(name + "发送了一条信息：" + message);
    }

    @Override
    public void response() {
        System.out.println(name + "收到一条新消息！");
    }

}
```

测试观察者模式

```
public class TestObserver {

    public static void main(String[] args) {
        // 聊天室
        Subject chatroom = new Chatroom();

        Observer chatter1 = new Chatter("张三");
        Observer chatter2 = new Chatter("李四");
        Observer chatter3 = new Chatter("王五");

        // 依次添加到观察者列表
        chatroom.addObserver(chatter1);
        chatroom.addObserver(chatter2);
        chatroom.addObserver(chatter3);

        ((Chatter) chatter1).sendMessage("大家好！");

        chatroom.notifyObserver();

    }

}
```


运行结果：

```
张三发送了一条信息：大家好！
张三收到一条新消息！
李四收到一条新消息！
王五收到一条新消息！
```

#### 解析：    

1. 降低了目标与观察者之间的耦合关系，两者之间是抽象耦合关系。
2. 目标与观察者之间建立了一套触发机制。










