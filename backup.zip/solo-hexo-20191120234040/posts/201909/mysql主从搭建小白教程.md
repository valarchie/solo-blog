title: mysql主从搭建小白教程
date: '2019-09-28 00:17:31'
updated: '2019-09-28 00:17:31'
tags: [mysql]
permalink: /articles/2019/09/28/1569601051745.html
---


### 先准备两台Mysql数据库

- 主数据库：192.168.0.106
- 从数据库：192.168.0.107


如果还没创建好数据库的话可以参考我之前的mysql搭建过程。
> [docker安装mysql小白教程](http://vc2x.com/articles/2019/09/26/1569508183164.html)


### 1.在主库创建同步账户Slave

```
CREATE USER 'slave'@'%'  IDENTIFIED BY 'slave123456';
```

如果出现以下异常的话。

```
ERROR 3009 (HY000): Column count of mysql.user is wrong. 
Expected 45, found 43. Created with MySQL 50645, now running 50727. 
Please use mysql_upgrade to fix this error.

```
就执行以下mysql_upgrade升级命令即可。

```
root@a8a64a905ed2:/# mysql_upgrade -u root -p
Enter password: 
```

创建成功

```
mysql> CREATE USER 'slave'@'%'  IDENTIFIED BY 'slave123456';
Query OK, 0 rows affected (0.00 sec)
```

添加账户权限


```
GRANT REPLICATION SLAVE ON *.* TO 'slave'@'%' IDENTIFIED BY 'slave123456' WITH GRANT OPTION;
```

### 2.添加主库配置信息
5.7版本的mysql，创建my.cnf文件放在/etc/mysql/conf.d/文件夹下，写入以下内容


```
[mysqld]
#主库id（任意填，主从库不要重复即可）
server_id=1  
#开启日志 名称为同步日志的开头
log_bin=mysql-bin     
   
#单个日志文件最大
max_binlog_size=512M  　
#日志有效期（天）
expire_logs_days=7          
#日志记录那些数据库
binlog_do_db=test
#日志记录忽略那些数据库的
binlog_ignore_db=mysql,performance_schema,information_schema,sys 

```
配置表当中有相当多的配置，以上简单的配置即可完成基础的主从复制，其他不填的话mysql会有默认的值，具体请参考完整的配置表。

配置好后重启mysql。进入到mysql当中后查看主库状态。

```
show master status;
```
将会看到创建好的二进制日志文件以及同步位置。
```
mysql> show master status;
+------------------+----------+--------------+-------------------------------------------------+-------------------+
| File             | Position | Binlog_Do_DB | Binlog_Ignore_DB                                | Executed_Gtid_Set |
+------------------+----------+--------------+-------------------------------------------------+-------------------+
| mysql-bin.000001 |      154 | test         | mysql,performance_schema,information_schema,sys |                   |
+------------------+----------+--------------+-------------------------------------------------+-------------------+
1 row in set (0.00 sec)
```
### 3.修改从库配置

配置文件的创建跟主库一样，内容如下

```
[mysqld]
#从库id（任意填，主从库不要重复即可）
server-id=2
#可以指定要复制的库
replicate-do-db=test
#日志过期时间
expire_logs_days=7
#只读
read_only=1
```
具体更详细的配置用法就省略了。

### 4.从库中设置要同步的主库信息


进入到从库当中修改要同步的主库信息。

```
mysql> stop slave;
```
填入刚才我们创建的同步账号密码、二进制同步文件名、同步坐标position
```
mysql> CHANGE MASTER TO
MASTER_HOST='192.168.0.106',
MASTER_USER='slave',
MASTER_PASSWORD='slave123456',
MASTER_PORT=3306,
MASTER_LOG_FILE='mysql-bin.000001',
MASTER_LOG_POS=154;
```
```
mysql> start slave;
```

查看从库信息

```
show slave status;
```

当出现以下状态时就成功了
- Slave_IO_State: Waiting for master to send event
- Slave_IO_Running: Yes
- Slave_SQL_Running: Yes
```
               Slave_IO_State: Waiting for master to send event
                  Master_Host: 192.168.0.106
                  Master_User: slave
                  Master_Port: 3306
                Connect_Retry: 60
              Master_Log_File: mysql-bin.000001
          Read_Master_Log_Pos: 1845
               Relay_Log_File: fcba403860b7-relay-bin.000002
                Relay_Log_Pos: 320
        Relay_Master_Log_File: mysql-bin.000001
             Slave_IO_Running: Yes
            Slave_SQL_Running: Yes
```
如果Slave_SQL_Running: no 的话，执行以下操作跳过错误的同步事件

```
stop slave;
set GLOBAL SQL_SLAVE_SKIP_COUNTER=1;
start slave;

```
或者重新设置最新同步的position直接跳过即可。



