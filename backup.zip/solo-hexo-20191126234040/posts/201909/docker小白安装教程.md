title: docker小白安装教程
date: '2019-09-26 00:52:14'
updated: '2019-09-26 00:54:39'
tags: [docker]
permalink: /articles/2019/09/26/1569430334324.html
---

### 通俗解释


#### 为什么
为什么需要docker呢？假设你想要部署一个服务，它可能依赖了JDK，又依赖了Mysql，又依赖了redis。这时候你告诉运维人员，你这个服务所需要的依赖有这些。这时候运维人员就需要去下载JDK，Mysql，Redis等等配置好一切，然后再拿到你的服务进行部署。而拥有了docker就不一样了，你只要将这个服务与JDK、Mysql、Redis一起打包成一个镜像丢给运维人员即可。运维人员直接运行这个打包好的镜像即可。

那docker为什么能做到这样呢？


#### 原理
我们之前会在自己的windows下通过vmware模拟出linux的虚拟机。但vmware模拟出来的虚拟机是将整个计算机包括硬件和软件一起虚拟出来。而docker比vmware更轻量，它模拟出来的是最精简的一个linux内核，每个容器里面相当于一个虚拟的linux。我们可以在这个虚拟的linux中，进行我们定制化的操作和配置，然后封装成镜像。下次别人使用时就不用重复地进行配置和操作了。

### 开始安装



#### 先卸载旧版本的docker

```
sudo yum remove docker \
              docker-client \
              docker-client-latest \
              docker-common \
              docker-latest \
              docker-latest-logrotate \
              docker-logrotate \
              docker-engine
```
如果之前有下载过docker的话，移除之前的版本以及相关的依赖。

#### 安装docker使用的仓库

1.安装所需的包（设备映射所需）。  
```
sudo yum install -y yum-utils \
  device-mapper-persistent-data \
  lvm2
```
2.设置docker的仓库。这一步很重要！一定要将官方仓库替换为阿里云的仓库，有时候下载慢下好几个小时...

```
sudo yum-config-manager --add-repo \
http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo

```
#### 选择可选的更新方式（默认stable：提供最新的可用版本，可以直接跳过进行安装）

1.正式版之前准备好测试的预发行版

```
sudo yum-config-manager --enable docker-ce-nightly
```
2.下个主要版本前的正在构建最新版本。

```
sudo yum-config-manager --enable docker-ce-test
```

#### 安装docker-ce版本

```
sudo yum install docker-ce
```
大概3分钟后执行安装成功。

#### 启动docker 

```
sudo systemctl start docker
```

#### 测试hello-world镜像

```
sudo docker run hello-world
```

当屏幕下方出现以下文字的话，代表已经启动镜像成功


```
Hello from Docker!
This message shows that your installation appears to be working correctly.

To generate this message, Docker took the following steps:
 1. The Docker client contacted the Docker daemon.
 2. The Docker daemon pulled the "hello-world" image from the Docker Hub.
    (amd64)
 3. The Docker daemon created a new container from that image which runs the
    executable that produces the output you are currently reading.
 4. The Docker daemon streamed that output to the Docker client, which sent it
    to your terminal.

```


#### （重要）配置阿里云提供的镜像加速

进入阿里云的镜像管理服务中心

> [阿里云容器镜像中心](https://cr.console.aliyun.com/cn-hangzhou/instances/mirrors)

你将会看到阿里云给你分配的镜像加速器

![TMRXHEMLCEAXH3A109.jpg](https://img.hacpai.com/file/2019/09/TMRXHEMLCEAXH3A109-3b60a72a.jpg)


复制红框内的语句执行即可。

```
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<-'EOF'
{
  "registry-mirrors": ["https://xxxx.mirror.aliyuncs.com"]
}
EOF
sudo systemctl daemon-reload
sudo systemctl restart docker
```
