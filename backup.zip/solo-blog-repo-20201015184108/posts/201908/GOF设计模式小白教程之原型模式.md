title: GOF设计模式小白教程之原型模式
date: '2019-08-28 20:46:40'
updated: '2019-09-03 23:59:12'
tags: [设计模式]
permalink: /articles/2019/08/28/1566996400628.html
---

### 原型模式（Prototype）

#### 定义：
用一个已经创建的实例作为原型，通过复制该原型对象来创建一个和原型相同或相似的新对象。在这里，原型实例指定了要创建的对象的种类。用这种方式创建对象非常高效，根本无须知道对象创建的细节。


#### 通俗解释：
美术课上老师布置了一个素描作业。然后同学们让美术课代表画了素描作业。其他同学就可以拿着这份素描作业去复印店复印。其他同学完全不用知道怎么画这个素描。美术课代表画的素描作业就是已经创建实例。它作为原型。用这个原型复制出新素描的话，无需关心素描细节。



#### 代码：
实现了Cloneable的素描类，并重写了clone方法

```
public class Sketch implements Cloneable {

    private String img;

    public Sketch(String content) {
        img = content;
    }

    public void show() {
        System.out.println("画的内容：" + img);
    }

    public Sketch clone() throws CloneNotSupportedException {
        return (Sketch) super.clone();
    }

}
```

原型测试类，新建一张素描再通过复制展示出来

```
public class TestPrototype {

    public static void main(String[] args) throws CloneNotSupportedException {
        Sketch sketch1 = new Sketch("A beautiful girl");
        sketch1.show();

        Sketch sketch2 = sketch1.clone();
        sketch2.show();
    }
}
```

运行结果：
```
画的内容：A beautiful girl
画的内容：A beautiful girl
```

#### 解析：     
Java自带的clone方法使得原型模式的实现非常简单，只需要重写一下clone方法即可。在创建对象比较麻烦繁琐的时候使用原型模式可以大大提高效率。






