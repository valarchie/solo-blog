title: 我在 GitHub 上的开源项目
date: '2020-10-12 18:41:07'
updated: '2020-10-12 18:41:07'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [java_technology_summary](https://github.com/valarchie/java_technology_summary) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/valarchie/java_technology_summary/watchers "关注数")&nbsp;&nbsp;[⭐️`13`](https://github.com/valarchie/java_technology_summary/stargazers "收藏数")&nbsp;&nbsp;[🖖`4`](https://github.com/valarchie/java_technology_summary/network/members "分叉数")&nbsp;&nbsp;[🏠`http://vc2x.com`](http://vc2x.com "项目主页")</span>

Java工程师技术知识点总结 - 面试向 - 分布式 - MQ - 缓存 - 架构 - 知识体系脑图



---

### 2. [quickboot](https://github.com/valarchie/quickboot) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/valarchie/quickboot/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/valarchie/quickboot/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/valarchie/quickboot/network/members "分叉数")</span>

基于springboot的小型快速开发框架



---

### 3. [solo-blog](https://github.com/valarchie/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/valarchie/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/valarchie/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/valarchie/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://vc2x.com`](http://vc2x.com "项目主页")</span>

✍️ CoderV的进阶笔记 - <br> Everybody wants go to heaven, but nobody wants to die.

