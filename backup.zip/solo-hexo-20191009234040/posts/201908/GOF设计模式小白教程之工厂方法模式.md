title: GOF设计模式小白教程之工厂方法模式
date: '2019-08-27 22:21:25'
updated: '2019-09-03 23:54:57'
tags: [设计模式]
permalink: /articles/2019/08/27/1566915685862.html
---

### 工厂方法

#### 定义：
定义一个创建产品对象的工厂接口，将产品对象的实际创建工作推迟到具体子工厂类当中。这符合六大原则中的依赖倒置原则。依赖抽象而不依赖实现。


#### 通俗解释：
有一个顾客想去4S店试车，不管他去到哪一家4S店只要说我想试车。他就会得到一辆试驾车。这里的顾客就是用户类，说“我想试车”就是用户的调用方法。4S店就是抽象工厂。具体工厂有宝马4S店，奔驰4S店。车就是抽象商品，宝马车奔驰车就是具体商品。下一次顾客去沃尔沃4S店的话，还是只需要说原来的那句话“我想试车”。不需要改变自己的话就可以得到其他4S店的试驾车。



#### 代码：
抽象工厂类：4S店

```
public interface Abstract4S {
    Car getCar();
}
```

具体工厂类：奔驰4S店和宝马4S店

```
public class Benz4S implements Abstract4S{
    @Override
    public Car getCar() {
        return new BenzCar();
    }
}
```
```
public class Bmw4S implements Abstract4S{
    @Override
    public Car getCar() {
        return new BwmCar();
    }
}

```

抽象商品类：车子

```
public interface Car {
    void start();
}
```

具体商品类：奔驰车、宝马车

```
public class BenzCar implements Car{
    @Override
    public void start() {
        System.out.println("启动奔驰车！");
    }
}
```

```
public class BwmCar implements Car{
    @Override
    public void start() {
        System.out.println("启动宝马车！");
    }
}

```
用户类调用试车方法：

```
public class TestDriveCar {

    public static void main(String[] args) {
        // 同一个方法可以处理不同4S店的试车
        testCar(new Benz4S());
        testCar(new Bmw4S());

    }

    public static void testCar(Abstract4S fourS) {
        Car car = fourS.getCar();
        car.start();
    }

}
```
运行结果：
```
启动奔驰车！
启动宝马车！
```



#### 解析：     
在系统增加新的产品时只需要添加具体产品类和对应的具体工厂类，无须对原工厂进行任何修改，  
满足开闭原则；其缺点是：每增加一个产品就要增加一个具体产品类和一个对应的具体工厂类，  
这增加了系统的复杂度。



