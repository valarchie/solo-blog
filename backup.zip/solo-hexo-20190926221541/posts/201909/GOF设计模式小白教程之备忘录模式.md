title: GOF设计模式小白教程之备忘录模式
date: '2019-09-01 23:29:59'
updated: '2019-09-01 23:29:59'
tags: [设计模式]
permalink: /articles/2019/09/01/1567351799096.html
---

### 备忘录模式（Memento）



#### 定义：
在不破坏封装性的前提下，捕获一个对象的内部状态，并在该对象之外保存这个状态，以便以后当需要时能将该对象恢复到原先保存的状态。该模式又叫快照模式。



#### 通俗解释：
我们玩角色扮演单机游戏的时候都需要进行存档。如果角色不小心死亡或者任务失败的时候我们就可以从之前存储的多个存档进行恢复。我们在IDEA编写代码的时候，发现修改错了，也可以用Ctrl+Z进行撤销修改，恢复到一开始的代码。


#### 代码：

发起者：记录当前时刻的内部状态信息，提供创建备忘录和恢复备忘录数据的功能，实现其他业务功能，它可以访问备忘录里的所有信息。

```
public class Originator {

    private String state;
    // 创建一个备忘录
    public Memento createMemento() {
        return new Memento(state);
    }
    // 从一个备忘录中恢复状态
    public void restoreMemento(Memento memento) {
        this.state = memento.getState();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
```


备忘录：负责存储发起人的内部状态，在需要的时候提供这些内部状态给发起人。


```
public class Memento {
    // 状态
    private String state;

    public Memento(String state) {
        this.state = state;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

}
```

管理者：对备忘录进行管理，提供保存与获取备忘录的功能，但其不能对备忘录的内容进行访问与修改。


```
public class Caretaker {
    // 保存备忘录的栈
    private Stack<Memento> mementos = new Stack<>();
    // 添加到备忘录栈
    public void addMemento(Memento memento) {
        mementos.add(memento);
    }
    // 从栈中获取备忘录
    public Memento getMemento() {
        return mementos.pop();
    }

}
```

测试备忘录，我们以单机游戏的存档作为例子。

```
public class TestMemento {

    public static void main(String[] args) {
        // 发起者
        Originator originator = new Originator();
        // 备忘录工具
        Caretaker caretaker = new Caretaker();

        originator.setState("当前第一关，血量100！");
        caretaker.addMemento(originator.createMemento());
        System.out.println(originator.getState());

        originator.setState("当前第二关，血量50！");
        caretaker.addMemento(originator.createMemento());
        System.out.println(originator.getState());

        originator.setState("当前第三关，血量0！角色死亡！");
        caretaker.addMemento(originator.createMemento());
        System.out.println(originator.getState());

        System.out.println("开始回档！");
        // 开始回档
        originator.restoreMemento(caretaker.getMemento());
        System.out.println(originator.getState());

        originator.restoreMemento(caretaker.getMemento());
        System.out.println(originator.getState());

        originator.restoreMemento(caretaker.getMemento());
        System.out.println(originator.getState());


    }

}
```


运行结果：

```
当前第一关，血量100！
当前第二关，血量50！
当前第三关，血量0！角色死亡！
开始回档！
当前第三关，血量0！角色死亡！
当前第二关，血量50！
当前第一关，血量100！
```

#### 解析：     

1. 提供了一种可以恢复状态的机制。当用户需要时能够比较方便地将数据恢复到某个历史的状态。
2. 实现了内部状态的封装。除了创建它的发起人之外，其他对象都不能够访问这些状态信息。
3. 简化了发起人类。发起人不需要管理和保存其内部状态的各个备份，所有状态信息都保存在备忘录中，并由管理者进行管理，这符合单一职责原则。










