title: GOF设计模式小白教程之门面模式
date: '2019-08-30 00:48:56'
updated: '2019-08-30 00:48:56'
tags: [设计模式]
permalink: /articles/2019/08/30/1567097336088.html
---

### 门面模式（Facade）

#### 定义：
是一种通过为多个复杂的子系统提供一个一致的接口，而使这些子系统更加容易被访问的模式。该模式对外有一个统一接口，外部应用程序不用关心内部子系统的具体的细节，这样会大大降低应用程序的复杂度，提高了程序的可维护性。


#### 通俗解释：
玩单反的人都知道要出拍一张好的照片，涉及到调光圈，快门，调焦距，ISO等复杂的拍摄技巧。那普通人想拍照又不想学这些复杂的拍摄技巧呢？不用担心，因为有傻瓜相机，只需要按一下快门即可拍出一张照片。傻瓜相机就相当于一个门面，而那些光圈，快门，焦距属于复杂的子系统。我们就通过门面，屏蔽了子系统的复杂性。




#### 代码：

光圈类，用于调整光圈

```
public class Aperture {
    void adjustLight() {
        System.out.println("调整光圈！");
    }
}
```

焦距类，用于调整焦距

```
public class Focal {
    void adjustFocus() {
        System.out.println("调整好焦距！");
    }
}
```
快门类，用于按下快门

```
public class Shutter {
    void click() {
        System.out.println("按下快门！");
    }
}
```
傻瓜相机类，相当于门面Facade，封装了复杂的拍照


```
public class DumpCamera {

    private Focal focal;
    private Aperture aperture;
    private Shutter shutter;

    public DumpCamera() {
        focal = new Focal();
        aperture = new Aperture();
        shutter = new Shutter();
    }
    // 拍照
    public void takePhoto() {

        focal.adjustFocus();
        aperture.adjustLight();
        shutter.click();

        System.out.println("拍出一张好照片！");

    }

}
```

测试门面模式

```
public class TestFacade {

    public static void main(String[] args) {

        DumpCamera camera = new DumpCamera();
        camera.takePhoto();

    }

}
```

运行结果：

```
调整好焦距！
调整光圈！
按下快门！
拍出一张好照片！
```


#### 解析：     
1. 该模式很好的实践了迪米特法则的思想。
2. 因为用户不直接与子系统交互，所以降低了子系统与客户端之间的耦合度，使得子系统的变化不会影响调用它的客户类。
3. 对客户屏蔽了子系统组件，减少了客户处理的对象数目，并使得子系统使用起来更加容易。
4. 增加新的子系统可能需要修改外观类或客户端的源代码，违背了“开闭原则”。








