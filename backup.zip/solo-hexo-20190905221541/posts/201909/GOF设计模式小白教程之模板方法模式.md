title: GOF设计模式小白教程之模板方法模式
date: '2019-09-02 22:12:56'
updated: '2019-09-02 22:12:56'
tags: [设计模式]
permalink: /articles/2019/09/02/1567433576191.html
---

### 模板方法模式（Template Method）



#### 定义：
定义一个操作中的算法骨架，而将算法的一些步骤延迟到子类中，使得子类可以不改变该算法结构的情况下重定义该算法的某些特定步骤。它是一种类行为型模式。



#### 通俗解释：
好比相亲一样，媒人跟男方说，你们约会的流程就是先逛街，再吃饭，再看电影，然后就结束约会啦。具体怎么逛街，吃什么饭，看什么电影，男方自己决定。模板方法模式就是这么的简单。





#### 代码：

抽象类：约会类，给出了具体约会的流程并要求子类要实现各自的逛街，吃饭，看电影的方法。


```
public abstract class DateGirl {

    // 逛街
    public abstract void shopping();
    // 吃饭
    public abstract void eating();
    // 看电影
    public abstract void seeMovie();

    // 规定了与女孩约会的流程
    public void howToDateGirl() {
        shopping();
        eating();
        seeMovie();
    }

}

```

具体子类：实现了逛街，吃饭，看电影的方法。


```
public class MyDateGril extends DateGirl {
    @Override
    public void shopping() {
        System.out.println("去中山街逛街！");
    }

    @Override
    public void eating() {
        System.out.println("去吃王品！");
    }

    @Override
    public void seeMovie() {
        System.out.println("去看《速度与激情》！");
    }
}
```

测试模板方法模式


```
public class TestTemplateMethod {

    public static void main(String[] args) {

        DateGirl me = new MyDateGril();
        me.howToDateGirl();

    }

}
```


运行结果：

```
去中山街逛街！
去吃王品！
去看《速度与激情》！
```


#### 解析：     
 1. 封装不变部分，扩展可变部分，符合开闭原则。 
 2. 提取公共代码，便于维护。 
 3. 行为由父类控制，子类实现。 









