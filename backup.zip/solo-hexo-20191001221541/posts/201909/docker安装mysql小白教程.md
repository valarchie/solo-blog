title: docker安装mysql小白教程
date: '2019-09-26 22:29:43'
updated: '2019-09-26 22:49:53'
tags: [docker]
permalink: /articles/2019/09/26/1569508183164.html
---


如果还没有安装好docker的话可以参考我之前的docker安装教程
> [docker小白安装教程](http://vc2x.com/articles/2019/09/26/1569430334324.html)




#### 1.先搜索一下mysql镜像列表


```
docker search mysql
```

出现以下mysql相关的镜像列表，列表中有Star数、Official（是否官方）等参数，默认按Star数排列。

```
NAME                              DESCRIPTION                                     STARS               OFFICIAL            AUTOMATED
mysql                             MySQL is a widely used, open-source relation…   8621                [OK]                
mariadb                           MariaDB is a community-developed fork of MyS…   2997                [OK]                
mysql/mysql-server                Optimized MySQL Server Docker images. Create…   637                                     [OK]
centos/mysql-57-centos7           MySQL 5.7 SQL database server                   63                                      
centurylink/mysql                 Image containing mysql. Optimized to be link…   61                                      [OK]
mysql/mysql-cluster               Experimental MySQL Cluster Docker images. Cr…   51                                      
deitch/mysql-backup               REPLACED! Please use http://hub.docker.com/r…   41                                      [OK]
tutum/mysql                       Base docker image to run a MySQL database se…   34                                      
bitnami/mysql                     Bitnami MySQL Docker Image                      33                                      [OK]
schickling/mysql-backup-s3        Backup MySQL to S3 (supports periodic backup…   28                                      [OK]
prom/mysqld-exporter                                                              23                                      [OK]

```


#### 2.拉取mysql的镜像

执行拉取镜像语句
```
docker pull mysql:5.7
```
开始出现下载提示

```
5.7: Pulling from library/mysql
8f91359f1fff: Pull complete 
6bbb1c853362: Pull complete 
e6e554c0af6f: Pull complete 
f391c1a77330: Pull complete 
414a8a88eabc: Pull complete 
fee78658f4dd: Pull complete 
9568f6bff01b: Pull complete 
76041efb6f83: Pull complete 
ea54dbd83183: Pull complete 
566857d8f022: Pull complete 
01c09495c6e7: Pull complete 
Digest: sha256:f7985e36c668bb862a0e506f4ef9acdd1254cdf690469816f99633898895f7fa
Status: Downloaded newer image for mysql:5.7
docker.io/library/mysql:5.7

```
下载结束后执行docker查看镜像

```
docker images
```
确认已经出现mysql 5.7的镜像

```
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
mysql               5.7                 383867b75fd2        2 weeks ago         373MB

```
#### 3.启动Mysql容器

执行以下语句

```
docker run -p 3306:3306 --name mysql \
 -v /usr/local/mysql/conf:/etc/mysql/conf.d \
 -v /usr/local/mysql/logs:/logs \
 -v /usr/local/mysql/data:/var/lib/mysql \
 -e MYSQL_ROOT_PASSWORD=root123456 \
 -d mysql:5.7

```

稍微解释以下这段启动语句

```
# run是启动命令  -p是端口映射 将本机的3306映射到容器里的3306端口 
# -name为容器设置名称，如果没有设置会有默认的随机名称
docker run -p 3306:3306 --name mysql \
# -v是挂载容器卷  
# 将mysql的各个主要文件夹映射到宿主机上
 -v /usr/local/mysql/conf:/etc/mysql/conf.d \
 -v /usr/local/mysql/logs:/logs \
 -v /usr/local/mysql/data:/var/lib/mysql \
# -e是传入环境变量  传入mysql root用户的密码
 -e MYSQL_ROOT_PASSWORD=root123456 \
# -d是后台运行容器 后面跟着镜像的名称
 -d mysql:5.7
```



此时查看docker进程

```
docker ps
```
将会看到mysql容器已经在运行当中

```
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS                               NAMES
0dacc263341b        mysql:5.7           "docker-entrypoint.s…"   6 seconds ago       Up 4 seconds        0.0.0.0:3306->3306/tcp, 33060/tcp   mysql

```
#### 4.验证Mysql

此时容器已创建好，可以直接用navicat连接到容器内的mysql。  
也可以进入到容器内部进行验证。

中间那一串id是你们本机上正在运行的容器id。
```
docker exec -it 0dacc263341b /bin/bash
```
登录mysql

```
root@0dacc263341b:/# mysql -u root -p
Enter password: 
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 6
Server version: 5.7.27 MySQL Community Server (GPL)

```
OK!安装成功咯~

